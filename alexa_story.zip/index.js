var Alexa = require('alexa-sdk');
var axios = require ("axios");

const APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

const languageStrings = {
    'en-US': {
        translation: {
            DOC: 'this is a sample document!',
            PAUSE_MESSAGE: "Pausing.",
            READ_DOC_MESSAGE: "Okay, I will go find it. I will read your document now: ",
            STOP_MESSAGE: 'Goodbye! Good luck with your studies!',
        },
    },
};

const handlers = {
    'LaunchRequest': function () {
        //this.emit('ReadDoc');
		const speechOutput = this.t('READ_DOC_MESSAGE') + this.t('DOC');
        this.emit(':tellWithCard', speechOutput);

		
    },
    'PauseIntent': function () {
        this.emit(this.t('PAUSE_MESSAGE'));
    },
    'ReadDoc': function () {
		
		var data;
		
		axios.get('http://savvy-celerity-117610.appspot.com/')
			.then(function(response){
				data = response.data;
				console.log(response.data);
			})
			.catch(function(error){
			console.log(error + "this is an error");
			});
	
        const speechOutput = this.t('READ_DOC_MESSAGE') + this.t('DOC') + this.t(data) + this.t('save me');
		
        this.emit(':tellWithCard', speechOutput);
    },
	
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
    'SessionEndedRequest': function () {
        this.emit(':tell', this.t('STOP_MESSAGE'));
    },
};

exports.handler = (event, context) => {
    const alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    // To enable string internationalization (i18n) features, set a resources object.
    alexa.resources = languageStrings;
    alexa.registerHandlers(handlers);
    alexa.execute();
};
